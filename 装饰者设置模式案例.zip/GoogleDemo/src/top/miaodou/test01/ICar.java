package top.miaodou.test01;

public interface ICar {
	public void start();
	public void run();
	public void stop();
}
