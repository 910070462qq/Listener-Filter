package top.miaodou.test02;

public interface ICar {
	public void start();
	public void run();
	public void stop();
}
