package top.miaodou.test02;

public class MyCar implements ICar {
	ICar car;

	public MyCar(ICar car) {
		this.car = car;
	}

	public void start() {
		car.start();
		System.out.println("检查天气是否良好");
		System.out.println("检查路况是否拥堵");
	}

	public void run() {
		// TODO Auto-generated method stub
		car.run();
	}

	public void stop() {
		// TODO Auto-generated method stub
		car.stop();
	}

}
