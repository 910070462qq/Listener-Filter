package top.miaodou.test02;

public class GoogleCar implements ICar{

	public void start() {
		System.out.println("控制谷歌的汽车启动");
	}

	public void run() {
		System.out.println("控制谷歌的汽车运行");
		
	}

	public void stop() {
		System.out.println("控制谷歌的汽车停止");
	}

}
