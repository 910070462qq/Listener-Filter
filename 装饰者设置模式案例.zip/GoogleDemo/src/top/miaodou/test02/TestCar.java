package top.miaodou.test02;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

public class TestCar {

	public static void main(String[] args) { 
		//参数1：固定值：告诉虚拟机用哪个字节码加载器加载内存中创建出的字节码文件。
		//参数2：告诉虚拟机内存中正在被创建的字节码文件中应该有哪些方法
		//参数3：告诉虚拟机正在被创建的字节码上的各个方法如何处理
		ICar car = (ICar) Proxy.newProxyInstance(TestCar.class.getClassLoader(),GoogleCar.class.getInterfaces(),new InvocationHandler() {
			
			public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
				
				//经过测试得知，method代表当前正在执行的每个方法
//				System.out.println(method.getName());
//				method.invoke(new GoogleCar(), args);
				
				if(method.getName().equalsIgnoreCase("start")){
					System.out.println("检查天气是否良好");
					System.out.println("路况是否拥堵");
				}else{
					
				}
				method.invoke(new GoogleCar(), args);
				
				return null;
			}
		});
		
		car.start();
		car.run();
		car.stop();
	}

}
